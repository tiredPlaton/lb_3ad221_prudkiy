public class Task5 {
    public static void main(String[] args) {
        String firstString = "Вася";
        String secondString = "12345678";
        System.out.println("Перша строка: " + firstString);
        System.out.println("Друга строка: " + secondString);
        System.out.println("Ітогова строка: " + mergeStrings(firstString, secondString));
    }

    public static String mergeStrings(String a, String b) {
        // Створення об'єкта StringBuilder для побудови результуючого рядка
        StringBuilder result = new StringBuilder();
        int i = 0; // Ініціалізація лічильника
        // Прохід по кожному символу обох рядків
        while (i < a.length() || i < b.length()) {
            // Якщо ще є символи в першому рядку, додаємо наступний символ до результату
            if (i < a.length()) {
                result.append(a.charAt(i));
            }
            // Якщо ще є символи в другому рядку, додаємо наступний символ до результату
            if (i < b.length()) {
                result.append(b.charAt(i));
            }
            i++; // Збільшуємо лічильник
        }
        return result.toString();
    }
}
