public class Task4 {
    public static void main(String[] args) {
        printWords("Іван Іванович Іванов");
    }

    public static void printWords(String input) {
        // Виведення вихідного рядка
        System.out.println("Вихідний рядок: " + input);

        // Розділення вхідного рядка на слова за пробілами
        String[] words = input.split("\\s+");

        // Виведення кожного слова на новому рядку
        for (String word : words) {
            System.out.println(word);
        }
    }
}