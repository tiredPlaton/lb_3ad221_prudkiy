// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        System.out.println(Task1.endsWithEd("blendered")); // повертає true
        System.out.println(Task1.endsWithEd("amazon"));  // повертає false

        System.out.println("Завдання 2:");
        System.out.println(Task2.sumOfDigits("laba123")); // повертає 6
        System.out.println(Task2.sumOfDigits("Sorry"));    // повертає 0

        System.out.println("Завдання 3:");
        System.out.println(Task3.longestBlockLength("aaBCS")); // повертає 2

        System.out.println("Завдання 4:");
        Task4.printWords("Іван Іванович Іванов");

        System.out.println("Завдання 5:");
        String firstString = "Вася";
        String secondString = "12345678";
        System.out.println("Перша строка: " + firstString);
        System.out.println("Друга строка: " + secondString);
        System.out.println("Ітогова строка: " + Task5.mergeStrings(firstString, secondString));
    }
}