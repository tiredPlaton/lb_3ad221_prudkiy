public class Task2 {
    public static void main(String[] args) {
        System.out.println(sumOfDigits("laba123")); // повертає 6
        System.out.println(sumOfDigits("Sorry"));    // повертає 0
    }

    public static int sumOfDigits(String input) {
        int sum = 0;
        // Прохід по кожному символу в рядку
        for (char c : input.toCharArray()) {
            // Перевірка, чи є символ цифрою
            if (Character.isDigit(c)) {
                // Якщо символ є цифрою, додаємо його числове значення до суми
                sum += Character.getNumericValue(c);
            }
        }
        return sum;
    }
}
