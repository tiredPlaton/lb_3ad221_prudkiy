public class Task1 {
    public static void main(String[] args) {
        System.out.println(endsWithEd("blendered")); // повертає true
        System.out.println(endsWithEd("amazon"));  // повертає false
    }
    // Метод, який перевіряє, чи рядок закінчується на "ed"
    public static boolean endsWithEd(String input) {
        return input.endsWith("ed");
    }
}
