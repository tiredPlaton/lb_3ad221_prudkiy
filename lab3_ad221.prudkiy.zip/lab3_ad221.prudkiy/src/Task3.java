public class Task3 {
    public static void main(String[] args) {
        System.out.println(longestBlockLength("aaBCS")); // повертає 2
    }

    public static int longestBlockLength(String input) {
        int maxBlockLength = 0; // Ініціалізація змінної для зберігання максимальної довжини блоку
        int currentBlockLength = 1; // Ініціалізація змінної для зберігання довжини поточного блоку

        // Прохід по кожному символу в рядку, починаючи з другого символу
        for (int i = 1; i < input.length(); i++) {
            // Перевірка, чи є поточний символ таким самим, як попередній
            if (input.charAt(i) == input.charAt(i - 1)) {
                // Збільшуємо довжину поточного блоку
                currentBlockLength++;
            } else {
                // Оновлюємо максимальну довжину блоку, якщо поточний блок довший
                maxBlockLength = Math.max(maxBlockLength, currentBlockLength);
                // Починаємо новий блок
                currentBlockLength = 1;
            }
        }
        return Math.max(maxBlockLength, currentBlockLength);
    }
}
